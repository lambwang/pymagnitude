/* Recycle depends on CPython GC */
#define AB_NRECYCLE 0
