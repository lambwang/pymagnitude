#define APSW_VERSION "3.25.2-r1"
