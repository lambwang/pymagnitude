# pylint: disable=wrong-import-position

# Make sure that allennlp is running in Python 3.6
from __future__ import absolute_import
import sys

