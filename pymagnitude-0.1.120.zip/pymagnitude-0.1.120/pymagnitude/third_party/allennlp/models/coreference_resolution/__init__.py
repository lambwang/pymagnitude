
from __future__ import absolute_import
from allennlp.models.coreference_resolution.coref import CoreferenceResolver
